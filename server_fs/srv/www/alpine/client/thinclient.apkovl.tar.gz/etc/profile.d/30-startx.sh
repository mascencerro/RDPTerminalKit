#!/bin/sh
exec startx